from django.urls import path
from .views import homeview,Loginview, loginpagedisplay, ProductCreateView,ProductUpdateView,displaylist,ProductDeleteview,SignupLogin,LogoutView

urlpatterns = [
    path('',SignupLogin.as_view(), name='signup'),
    path('home/',homeview, name='home'),
    path('createproduct/',ProductCreateView.as_view(),name='createview'),
    path('update/<int:pk>/',ProductUpdateView.as_view(),name='update'),
    path('delete/<int:pk>/',ProductDeleteview.as_view(),name='delete'),
    path('displaylist/',displaylist,name='display'),
    path('loginpagedisplay/',loginpagedisplay.as_view(),name="loginpage"),
    path('login/',Loginview.as_view(),name="login"),
    path('logout/',LogoutView.as_view(),name='logout')
 
    
]
