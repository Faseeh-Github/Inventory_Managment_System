from django import forms
from .models import Product
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
from django.contrib.auth.models import User

class Product_form(forms.ModelForm):
    class Meta:
        model=Product
        fields='__all__'
        
        label={
            'product_id':'Product_ID',
            'name':"Name",
            'sku':'SKU',
            'price':'Price',
            'quantity':'Quantity',
            'supplier':'Supplier'
        }
        widget={
            'product_id':forms.NumberInput(attrs={'placeholder':'e.g:1', 'class':'form-control'}),
            'name':forms.TextInput(attrs={'placeholder':'e.g:Bag', 'class':'form-control' }),
            'sku':forms.TextInput(attrs={'placeholder':'e.g:1', 'class':'form-control'}),
            'price':forms.NumberInput(attrs={'placeholder':'e.g: 54$', 'class':'form-control'}),
            'qunatity':forms.NumberInput(attrs={'placeholder':'e.g: 3','class':'form-control'}),
            'supplier':forms.TextInput(attrs={'placeholder':'e.g: ABC','class':'form-control'})
        }
class Userform(UserCreationForm):
    
    class Meta:
        model=User
        fields=["username","password1",'password2']
        
        
        
class Loginform(AuthenticationForm):
    model=User
    feilds=['username','password']
