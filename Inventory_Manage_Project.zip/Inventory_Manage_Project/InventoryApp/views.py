from django.shortcuts import render,redirect,get_object_or_404
from .forms import Product_form, Userform,Loginform
from .models import Product
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic import DetailView
from django.urls import reverse_lazy
from django.views import View
from django.contrib.auth import login,logout,authenticate
from django.contrib.auth.views import LoginView
from django.contrib import messages
# Create your views here.

def homeview(request):
    return render(request, 'index.html')

class ProductDetailView(DetailView):
    model=Product
    template_name="Displayproduct.html"
    context_object_name='products'
    
class loginpagedisplay(View):
    def get(self,request):
        form=Loginform
        return render(request,'login.html',{"form":form})
     
def displaylist(request):
    product=Product.objects.all()
    return render(request,'displaylist.html',{"product":product})

class ProductCreateView(CreateView):
    template_name="form.html"
    form_class=Product_form
    success_url=reverse_lazy('display')
    
class ProductUpdateView(UpdateView):
    model = Product
    fields = ['name', 'sku', 'price', 'quantity', 'supplier']
    template_name = 'form.html'
    success_url = reverse_lazy('display')  
    
class ProductDeleteview(DeleteView):
    template_name="confirm_delete.html"
    model=Product
    success_url=reverse_lazy('display')
    
class SignupLogin(View):
    template_name = "signup.html"
    form_class = Userform
    success_url = reverse_lazy("home")
    
    def get(self, request):
        form = self.form_class()
        return render(request, self.template_name, {"form": form})  
    
    def post(self, request):
        form = self.form_class(request.POST)  
        if form.is_valid(): 
            user = form.save()
            login(request, user)
            return redirect(self.success_url) 
        return render(request, self.template_name, {"form": form})
    
class Loginview(LoginView):
    template_name = "login.html"
    success_url=reverse_lazy('home')
    redirect_authenticated_user = True

     
class Generic_login_view(LoginView):
    template_name="login.html"
    form_class=Loginform
    redirect_authenticated_user=True
    success_url=reverse_lazy("home")
    
class LogoutView(View):
    def get(self,request):
        logout(request)
        return redirect('loginpage')
        
    
    

    